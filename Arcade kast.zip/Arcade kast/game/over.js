var overState = {
	preload:function(){

		game.load.image('begin', 'assets/gameover.png');
		
	},

	create:function(){
		
		
		game.physics.startSystem(Phaser.Physics.ARCADE);
		game.add.image(0,0,'begin');

		var vkey = game.input.keyboard.addKey(Phaser.Keyboard.UP);

		vkey.onDown.addOnce(this.restart,this);

	},

	update:function(){

	},

	restart:function(){
		game.state.start('menu');

	}


}
