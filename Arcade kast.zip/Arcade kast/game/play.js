var road;
var turtle;
var steen;
var steen1;
var controls = {};
var auto;
var auto1;
var auto2;
var auto3;
var finish;
var gameover;

var score = 0;
var scoreString = '';
var scoreText;




var playState = {
	preload:function()
    {
    this.load.image('road','assets/road.jpg');
    this.load.image('steen','assets/steen.jpg');
    this.load.image('steen1','assets/steen.jpg');
    this.load.image('steen2','assets/steen.jpg');
    this.load.image('auto','assets/car.png');
    this.load.image('turtle', 'assets/turtles.png');
    this.load.image('finish','assets/Finish.png');
    },
    
    create:function()
    {   
    this.physics.startSystem(Phaser.Physics.ARCADE);
    this.physics.arcade.gravity.y = 0;
    
    this.road = this.add.tileSprite(0,0,1250,700,'road');
    this.physics.arcade.enable(this.road);
    
    this.steen = this.add.sprite(60,0,'steen');
    this.steen.enableBody=true;
    this.physics.arcade.enable(this.steen);
    this.steen.body.immovable = true;
    this.steen.width = 92;
    this.steen.height = 700;
    this.steen.alpha = 0;
    //this.steen.body.allowGravity = false;
    this.steen1 = this.add.sprite(860,0,'steen1');
    this.steen1.enableBody=true;
    this.physics.arcade.enable(this.steen1);
    this.steen1.body.immovable = true;
    this.steen1.width = 92;
    this.steen1.height = 700;
    this.steen1.alpha = 0;
    
    this.steen2 = this.add.sprite(0,750,'steen2');
    this.steen2.enableBody=true;
    this.physics.arcade.enable(this.steen2);
    this.steen2.body.immovable = true;
    this.steen2.width = 1000;
    this.steen2.height = 10;
    this.steen2.alpha = 0;
    
    this.turtle = this.add.sprite(455,400,'turtle');
    this.turtle.enableBody=true;
    this.physics.arcade.enable(this.turtle);
    this.turtle.scale.setTo(0.25);
    this.turtle.body.allowGravity = false;

    //HERE DOES THE CAR BEGIN
    this.auto = this.add.sprite(210,-10520,'auto');
    this.physics.arcade.enable(this.auto);
    this.auto.anchor.setTo(0.5);
    this.auto.scale.setTo(0.25);
    this.auto.body.immovable = true;

    this.auto1 = this.add.sprite(360,-10600,'auto');
    this.physics.arcade.enable(this.auto1);
    this.auto1.anchor.setTo(0.5);
    this.auto1.scale.setTo(0.25);
    this.auto1.body.immovable = true;

    this.auto2 = this.add.sprite(660,-10530,'auto');
    this.physics.arcade.enable(this.auto2);
    this.auto2.anchor.setTo(0.5);
    this.auto2.scale.setTo(0.25);
    this.auto2.body.immovable = true;

    this.auto3 = this.add.sprite(800,-10590,'auto');
    this.physics.arcade.enable(this.auto3);
    this.auto3.anchor.setTo(0.5);
    this.auto3.scale.setTo(0.25);
    this.auto3.body.immovable = true;

    //Eerste rij
    this.auto4 = this.add.sprite(210,-500,'auto');
    this.physics.arcade.enable(this.auto4);
    this.auto4.anchor.setTo(0.5);
    this.auto4.scale.setTo(0.25);
    this.auto4.body.immovable = true;

    this.auto5 = this.add.sprite(510,-400,'auto');
    this.physics.arcade.enable(this.auto5);
    this.auto5.anchor.setTo(0.5);
    this.auto5.scale.setTo(0.25);
    this.auto5.body.immovable = true;

    this.auto6 = this.add.sprite(800,-450,'auto');
    this.physics.arcade.enable(this.auto6);
    this.auto6.anchor.setTo(0.5);
    this.auto6.scale.setTo(0.25);
    this.auto6.body.immovable = true;

    //Tweede rij
    this.auto7 = this.add.sprite(800,-950,'auto');
    this.physics.arcade.enable(this.auto7);
    this.auto7.anchor.setTo(0.5);
    this.auto7.scale.setTo(0.25);
    this.auto7.body.immovable = true;

    this.auto8 = this.add.sprite(360,-1000,'auto');
    this.physics.arcade.enable(this.auto8);
    this.auto8.anchor.setTo(0.5);
    this.auto8.scale.setTo(0.25);
    this.auto8.body.immovable = true;

    //Derde rij
    this.auto9 = this.add.sprite(660,-1500,'auto');
    this.physics.arcade.enable(this.auto9);
    this.auto9.anchor.setTo(0.5);
    this.auto9.scale.setTo(0.25);
    this.auto9.body.immovable = true;

    this.auto10 = this.add.sprite(360,-1550,'auto');
    this.physics.arcade.enable(this.auto10);
    this.auto10.anchor.setTo(0.5);
    this.auto10.scale.setTo(0.25);
    this.auto10.body.immovable = true;

    this.auto11 = this.add.sprite(510,-1580,'auto');
    this.physics.arcade.enable(this.auto11);
    this.auto11.anchor.setTo(0.5);
    this.auto11.scale.setTo(0.25);
    this.auto11.body.immovable = true;

    //Vierde rij
    //Auto12
    this.auto12 = this.add.sprite(210,-1998,'auto');
    this.physics.arcade.enable(this.auto12);
    this.auto12.anchor.setTo(0.5);
    this.auto12.scale.setTo(0.25);
    this.auto12.body.immovable = true;

    //Auto13
    this.auto13 = this.add.sprite(510,-2000,'auto');
    this.physics.arcade.enable(this.auto13);
    this.auto13.anchor.setTo(0.5);
    this.auto13.scale.setTo(0.25);
    this.auto13.body.immovable = true;
    
    //Auto14
    this.auto14 = this.add.sprite(800,-2050,'auto');
    this.physics.arcade.enable(this.auto14);
    this.auto14.anchor.setTo(0.5);
    this.auto14.scale.setTo(0.25);
    this.auto14.body.immovable = true;

    //Vijfde rij
    //Auto15
    this.auto15 = this.add.sprite(210,-2550,'auto');
    this.physics.arcade.enable(this.auto15);
    this.auto15.anchor.setTo(0.5);
    this.auto15.scale.setTo(0.25);
    this.auto15.body.immovable = true;

    //Auto16
    this.auto16 = this.add.sprite(660,-2530,'auto');
    this.physics.arcade.enable(this.auto16);
    this.auto16.anchor.setTo(0.5);
    this.auto16.scale.setTo(0.25);
    this.auto16.body.immovable = true;

    //Zesde rij
    //Auto17
    this.auto17 = this.add.sprite(360,-3000,'auto');
    this.physics.arcade.enable(this.auto17);
    this.auto17.anchor.setTo(0.5);
    this.auto17.scale.setTo(0.25);
    this.auto17.body.immovable = true;

    //Auto18
    this.auto18 = this.add.sprite(510,-3050,'auto');
    this.physics.arcade.enable(this.auto18);
    this.auto18.anchor.setTo(0.5);
    this.auto18.scale.setTo(0.25);
    this.auto18.body.immovable = true;

    //Auto19
    this.auto19 = this.add.sprite(800,-3090,'auto');
    this.physics.arcade.enable(this.auto19);
    this.auto19.anchor.setTo(0.5);
    this.auto19.scale.setTo(0.25);
    this.auto19.body.immovable = true;

    //Zevende rij
    //Auto20
    this.auto20 = this.add.sprite(210,-3550,'auto');
    this.physics.arcade.enable(this.auto20);
    this.auto20.anchor.setTo(0.5);
    this.auto20.scale.setTo(0.25);
    this.auto20.body.immovable = true;

    //Auto21
    this.auto21 = this.add.sprite(360,-3500,'auto');
    this.physics.arcade.enable(this.auto21);
    this.auto21.anchor.setTo(0.5);
    this.auto21.scale.setTo(0.25);
    this.auto21.body.immovable = true;

    //Auto22
    this.auto22 = this.add.sprite(510,-3550,'auto');
    this.physics.arcade.enable(this.auto22);
    this.auto22.anchor.setTo(0.5);
    this.auto22.scale.setTo(0.25);
    this.auto22.body.immovable = true;

    //Auto23
    this.auto23 = this.add.sprite(800,-3520,'auto');
    this.physics.arcade.enable(this.auto23);
    this.auto23.anchor.setTo(0.5);
    this.auto23.scale.setTo(0.25);
    this.auto23.body.immovable = true;

    //Achtste rij
    //Auto24
    this.auto24 = this.add.sprite(210,-4050,'auto');
    this.physics.arcade.enable(this.auto24);
    this.auto24.anchor.setTo(0.5);
    this.auto24.scale.setTo(0.25);
    this.auto24.body.immovable = true;

    //Auto25
    this.auto25 = this.add.sprite(360,-4040,'auto');
    this.physics.arcade.enable(this.auto25);
    this.auto25.anchor.setTo(0.5);
    this.auto25.scale.setTo(0.25);
    this.auto25.body.immovable = true;

    //Auto26
    this.auto26 = this.add.sprite(660,-4030,'auto');
    this.physics.arcade.enable(this.auto26);
    this.auto26.anchor.setTo(0.5);
    this.auto26.scale.setTo(0.25);
    this.auto26.body.immovable = true;

    //Auto27
    this.auto27 = this.add.sprite(800,-4030,'auto');
    this.physics.arcade.enable(this.auto27);
    this.auto27.anchor.setTo(0.5);
    this.auto27.scale.setTo(0.25);
    this.auto27.body.immovable = true;

    //Negende rij
    //Auto28
    this.auto28 = this.add.sprite(210,-4480,'auto');
    this.physics.arcade.enable(this.auto28);
    this.auto28.anchor.setTo(0.5);
    this.auto28.scale.setTo(0.25);
    this.auto28.body.immovable = true;

    //Auto29
    this.auto29 = this.add.sprite(510,-4570,'auto');
    this.physics.arcade.enable(this.auto29);
    this.auto29.anchor.setTo(0.5);
    this.auto29.scale.setTo(0.25);
    this.auto29.body.immovable = true;

    //Auto30
    this.auto30 = this.add.sprite(810,-4550,'auto');
    this.physics.arcade.enable(this.auto30);
    this.auto30.anchor.setTo(0.5);
    this.auto30.scale.setTo(0.25);
    this.auto30.body.immovable = true;

    //Tiende
    //Auto31
    this.auto31 = this.add.sprite(210,-4988,'auto');
    this.physics.arcade.enable(this.auto31);
    this.auto31.anchor.setTo(0.5);
    this.auto31.scale.setTo(0.25);
    this.auto31.body.immovable = true;

    //Auto32
    this.auto32 = this.add.sprite(360,-4975,'auto');
    this.physics.arcade.enable(this.auto32);
    this.auto32.anchor.setTo(0.5);
    this.auto32.scale.setTo(0.25);
    this.auto32.body.immovable = true;

    //Auto33
    this.auto33 = this.add.sprite(510,-5010,'auto');
    this.physics.arcade.enable(this.auto33);
    this.auto33.anchor.setTo(0.5);
    this.auto33.scale.setTo(0.25);
    this.auto33.body.immovable = true;

    //Auto34
    this.auto34 = this.add.sprite(660,-5030,'auto');
    this.physics.arcade.enable(this.auto34);
    this.auto34.anchor.setTo(0.5);
    this.auto34.scale.setTo(0.25);
    this.auto34.body.immovable = true;

    //Elfde
    //Auto35
    this.auto35 = this.add.sprite(210,-5550,'auto');
    this.physics.arcade.enable(this.auto35);
    this.auto35.anchor.setTo(0.5);
    this.auto35.scale.setTo(0.25);
    this.auto35.body.immovable = true;

    //Auto36
    this.auto36 = this.add.sprite(360,-5530,'auto');
    this.physics.arcade.enable(this.auto36);
    this.auto36.anchor.setTo(0.5);
    this.auto36.scale.setTo(0.25);
    this.auto36.body.immovable = true;

    //Auto37
    this.auto37 = this.add.sprite(800,-5520,'auto');
    this.physics.arcade.enable(this.auto37);
    this.auto37.anchor.setTo(0.5);
    this.auto37.scale.setTo(0.25);
    this.auto37.body.immovable = true;

    //Twaalfde
    //Auto38
    this.auto38 = this.add.sprite(210,-6050,'auto');
    this.physics.arcade.enable(this.auto38);
    this.auto38.anchor.setTo(0.5);
    this.auto38.scale.setTo(0.25);
    this.auto38.body.immovable = true;

    //Auto39
    this.auto39 = this.add.sprite(660,-6030,'auto');
    this.physics.arcade.enable(this.auto39);
    this.auto39.anchor.setTo(0.5);
    this.auto39.scale.setTo(0.25);
    this.auto39.body.immovable = true;

    //Auto40
    this.auto40 = this.add.sprite(800,-6010,'auto');
    this.physics.arcade.enable(this.auto40);
    this.auto40.anchor.setTo(0.5);
    this.auto40.scale.setTo(0.25);
    this.auto40.body.immovable = true;

    //Dertiende
    //Auto41
    this.auto41 = this.add.sprite(210,-6490,'auto');
    this.physics.arcade.enable(this.auto41);
    this.auto41.anchor.setTo(0.5);
    this.auto41.scale.setTo(0.25);
    this.auto41.body.immovable = true;

     //Auto42
    this.auto42 = this.add.sprite(210,-6520,'auto');
    this.physics.arcade.enable(this.auto42);
    this.auto42.anchor.setTo(0.5);
    this.auto42.scale.setTo(0.25);
    this.auto42.body.immovable = true;

     //Auto43
    this.auto43 = this.add.sprite(360,-6530,'auto');
    this.physics.arcade.enable(this.auto43);
    this.auto43.anchor.setTo(0.5);
    this.auto43.scale.setTo(0.25);
    this.auto43.body.immovable = true;

     //Auto44
    this.auto44 = this.add.sprite(510,-6550,'auto');
    this.physics.arcade.enable(this.auto44);
    this.auto44.anchor.setTo(0.5);
    this.auto44.scale.setTo(0.25);
    this.auto44.body.immovable = true;

    //Veertiende
    //Auto45
    this.auto45 = this.add.sprite(210,-7010,'auto');
    this.physics.arcade.enable(this.auto45);
    this.auto45.anchor.setTo(0.5);
    this.auto45.scale.setTo(0.25);
    this.auto45.body.immovable = true;

     //Auto46
    this.auto46 = this.add.sprite(360,-7050,'auto');
    this.physics.arcade.enable(this.auto46);
    this.auto46.anchor.setTo(0.5);
    this.auto46.scale.setTo(0.25);
    this.auto46.body.immovable = true;

     //Auto47
    this.auto47 = this.add.sprite(510,-7080,'auto');
    this.physics.arcade.enable(this.auto47);
    this.auto47.anchor.setTo(0.5);
    this.auto47.scale.setTo(0.25);
    this.auto47.body.immovable = true;

     //Auto48
    this.auto48 = this.add.sprite(800,-7099,'auto');
    this.physics.arcade.enable(this.auto48);
    this.auto48.anchor.setTo(0.5);
    this.auto48.scale.setTo(0.25);
    this.auto48.body.immovable = true;

    //Vijftiende
    //Auto49
    this.auto49 = this.add.sprite(360,-7510,'auto');
    this.physics.arcade.enable(this.auto49);
    this.auto49.anchor.setTo(0.5);
    this.auto49.scale.setTo(0.25);
    this.auto49.body.immovable = true;

    //Auto50
    this.auto50 = this.add.sprite(660,-7570,'auto');
    this.physics.arcade.enable(this.auto50);
    this.auto50.anchor.setTo(0.5);
    this.auto50.scale.setTo(0.25);
    this.auto50.body.immovable = true;

    //Auto51
    this.auto51 = this.add.sprite(800,-7520,'auto');
    this.physics.arcade.enable(this.auto51);
    this.auto51.anchor.setTo(0.5);
    this.auto51.scale.setTo(0.25);
    this.auto51.body.immovable = true;

    //Zestiende
    //Auto52
    this.auto52 = this.add.sprite(210,-7980,'auto');
    this.physics.arcade.enable(this.auto52);
    this.auto52.anchor.setTo(0.5);
    this.auto52.scale.setTo(0.25);
    this.auto52.body.immovable = true;

    //Auto53
    this.auto53 = this.add.sprite(360,-8040,'auto');
    this.physics.arcade.enable(this.auto53);
    this.auto53.anchor.setTo(0.5);
    this.auto53.scale.setTo(0.25);
    this.auto53.body.immovable = true;

    //Auto54
    this.auto54 = this.add.sprite(660,-8030,'auto');
    this.physics.arcade.enable(this.auto54);
    this.auto54.anchor.setTo(0.5);
    this.auto54.scale.setTo(0.25);
    this.auto54.body.immovable = true;

    //Zeventiende
    //Auto55
    this.auto55 = this.add.sprite(510,-8530,'auto');
    this.physics.arcade.enable(this.auto55);
    this.auto55.anchor.setTo(0.5);
    this.auto55.scale.setTo(0.25);
    this.auto55.body.immovable = true;

    //Auto56
    this.auto56 = this.add.sprite(660,-8510,'auto');
    this.physics.arcade.enable(this.auto56);
    this.auto56.anchor.setTo(0.5);
    this.auto56.scale.setTo(0.25);
    this.auto56.body.immovable = true;

    //Auto57
    this.auto57 = this.add.sprite(800,-8500,'auto');
    this.physics.arcade.enable(this.auto57);
    this.auto57.anchor.setTo(0.5);
    this.auto57.scale.setTo(0.25);
    this.auto57.body.immovable = true;

    //Achtiende
    //Auto58
    this.auto58 = this.add.sprite(210,-9010,'auto');
    this.physics.arcade.enable(this.auto58);
    this.auto58.anchor.setTo(0.5);
    this.auto58.scale.setTo(0.25);
    this.auto58.body.immovable = true;

    //Auto59
    this.auto59 = this.add.sprite(510,-9050,'auto');
    this.physics.arcade.enable(this.auto59);
    this.auto59.anchor.setTo(0.5);
    this.auto59.scale.setTo(0.25);
    this.auto59.body.immovable = true;

    //Auto60
    this.auto60 = this.add.sprite(660,-9070,'auto');
    this.physics.arcade.enable(this.auto60);
    this.auto60.anchor.setTo(0.5);
    this.auto60.scale.setTo(0.25);
    this.auto60.body.immovable = true;

     //Auto61
    this.auto61 = this.add.sprite(800,-9030,'auto');
    this.physics.arcade.enable(this.auto61);
    this.auto61.anchor.setTo(0.5);
    this.auto61.scale.setTo(0.25);
    this.auto61.body.immovable = true;

    //Negentiende
    //Auto62
    this.auto62 = this.add.sprite(360,-9590,'auto');
    this.physics.arcade.enable(this.auto62);
    this.auto62.anchor.setTo(0.5);
    this.auto62.scale.setTo(0.25);
    this.auto62.body.immovable = true;

    //Auto63
    this.auto63 = this.add.sprite(510,-9580,'auto');
    this.physics.arcade.enable(this.auto63);
    this.auto63.anchor.setTo(0.5);
    this.auto63.scale.setTo(0.25);
    this.auto63.body.immovable = true;

    //Auto64
    this.auto64 = this.add.sprite(800,-9510,'auto');
    this.physics.arcade.enable(this.auto64);
    this.auto64.anchor.setTo(0.5);
    this.auto64.scale.setTo(0.25);
    this.auto64.body.immovable = true;

   //Twintigste
    //Auto65
    this.auto65 = this.add.sprite(510,-10080,'auto');
    this.physics.arcade.enable(this.auto65);
    this.auto65.anchor.setTo(0.5);
    this.auto65.scale.setTo(0.25);
    this.auto65.body.immovable = true;

    //Auto66
    this.auto66 = this.add.sprite(660,-10002,'auto');
    this.physics.arcade.enable(this.auto66);
    this.auto66.anchor.setTo(0.5);
    this.auto66.scale.setTo(0.25);
    this.auto66.body.immovable = true;

    //Auto67
    this.auto67 = this.add.sprite(800,-10030,'auto');
    this.physics.arcade.enable(this.auto67);
    this.auto67.anchor.setTo(0.5);
    this.auto67.scale.setTo(0.25);
    this.auto67.body.immovable = true;

    //FinishLine
    this.finish = this.add.sprite(158,-11000,'finish');
    this.physics.arcade.enable(this.finish);
    this.finish.scale.setTo(1.514,1.114);
    this.finish.body.immovable = true;

    scoreString = 'Score: 0';
    scoreText = game.add.text(16, 16, scoreString + score, { font: '32px', fill: '#fff' });
    
    this.controls = {
          right: this.input.keyboard.addKey(Phaser.Keyboard.RIGHT),
          left: this.input.keyboard.addKey(Phaser.Keyboard.LEFT),
          
        };
    },
    
    update:function()
    {
    this.road.tilePosition.y += 3;
    this.turtle.body.velocity.x = 0;

    if (this.controls.left.isDown){
      this.turtle.body.velocity.x = -200;  
    }

    if (this.controls.right.isDown){
        this.turtle.body.velocity.x = 200;
    }
    
    this.auto.body.velocity.y = 200;
    this.auto1.body.velocity.y = 200;
    this.auto2.body.velocity.y = 200;
    this.auto3.body.velocity.y = 200;

    this.auto4.body.velocity.y = 200;
    this.auto5.body.velocity.y = 200;
    this.auto6.body.velocity.y = 200;

    this.auto7.body.velocity.y = 200;
    this.auto8.body.velocity.y = 200;

    this.auto9.body.velocity.y = 200;
    this.auto10.body.velocity.y = 200;
    this.auto11.body.velocity.y = 200;
    this.auto12.body.velocity.y = 200;
    this.auto13.body.velocity.y = 200;
    this.auto14.body.velocity.y = 200;

    this.auto15.body.velocity.y = 200;
    this.auto16.body.velocity.y = 200;
    this.auto17.body.velocity.y = 200;
    this.auto18.body.velocity.y = 200;
    this.auto19.body.velocity.y = 200;
    
    this.auto20.body.velocity.y = 200;
    this.auto21.body.velocity.y = 200;
    this.auto22.body.velocity.y = 200;
    this.auto23.body.velocity.y = 200;
    this.auto24.body.velocity.y = 200;
    this.auto25.body.velocity.y = 200;
    this.auto26.body.velocity.y = 200;
    this.auto27.body.velocity.y = 200;

    this.auto28.body.velocity.y = 200;
    this.auto29.body.velocity.y = 200;
    this.auto30.body.velocity.y = 200;
    this.auto31.body.velocity.y = 200;
    this.auto32.body.velocity.y = 200;
    this.auto33.body.velocity.y = 200;
    this.auto34.body.velocity.y = 200;

    this.auto35.body.velocity.y = 200;
    this.auto36.body.velocity.y = 200;
    this.auto37.body.velocity.y = 200;
    this.auto38.body.velocity.y = 200;
    this.auto39.body.velocity.y = 200;
    this.auto40.body.velocity.y = 200;

    this.auto41.body.velocity.y = 200;
    this.auto42.body.velocity.y = 200;
    this.auto43.body.velocity.y = 200;
    this.auto44.body.velocity.y = 200;
    this.auto45.body.velocity.y = 200;
    this.auto46.body.velocity.y = 200;
    this.auto47.body.velocity.y = 200;
    this.auto48.body.velocity.y = 200;

    this.auto49.body.velocity.y = 200;
    this.auto50.body.velocity.y = 200;
    this.auto51.body.velocity.y = 200;
    this.auto52.body.velocity.y = 200;
    this.auto53.body.velocity.y = 200;
    this.auto54.body.velocity.y = 200;
    this.auto55.body.velocity.y = 200;
    this.auto56.body.velocity.y = 200;
    this.auto57.body.velocity.y = 200;

    this.auto58.body.velocity.y = 200;
    this.auto59.body.velocity.y = 200;
    this.auto60.body.velocity.y = 200;
    this.auto61.body.velocity.y = 200;
    this.auto62.body.velocity.y = 200;
    this.auto63.body.velocity.y = 200;
    this.auto64.body.velocity.y = 200;
    this.auto65.body.velocity.y = 200;
    this.auto66.body.velocity.y = 200;
    this.auto67.body.velocity.y = 200;


    this.finish.body.velocity.y = 200;

    //Turtle collision car
    this.physics.arcade.collide(this.turtle,this.auto,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto1,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto2,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto3,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto4,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto5,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto6,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto7,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto8,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto9,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto10,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto11,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto12,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto13,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto14,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto15,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto16,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto17,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto18,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto19,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto20,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto21,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto22,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto23,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto24,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto25,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto26,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto27,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto28,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto29,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto30,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto31,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto32,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto33,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto34,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto35,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto36,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto37,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto38,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto39,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto40,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto41,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto42,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto43,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto44,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto45,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto46,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto47,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto48,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto49,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto50,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto51,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto52,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto53,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto54,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto55,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto56,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto57,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto58,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto59,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto60,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto61,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto62,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto63,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto64,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto65,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto66,this.gameover,null,this);
    this.physics.arcade.collide(this.turtle,this.auto67,this.gameover,null,this);

    //Scoretext colision
    this.physics.arcade.collide(this.auto,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto1,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto2,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto3,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto4,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto5,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto6,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto7,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto8,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto9,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto10,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto11,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto12,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto13,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto14,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto15,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto16,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto17,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto18,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto19,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto20,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto21,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto22,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto23,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto24,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto25,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto26,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto27,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto28,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto29,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto30,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto31,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto32,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto33,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto34,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto35,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto36,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto37,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto38,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto39,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto40,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto41,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto42,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto43,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto44,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto45,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto46,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto47,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto48,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto49,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto50,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto51,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto52,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto53,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto54,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto55,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto56,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto57,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto58,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto59,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto60,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto61,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto62,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto63,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto64,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto65,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto66,this.steen2,this.carAway,null,this);
    this.physics.arcade.collide(this.auto67,this.steen2,this.carAway,null,this);
    


    this.physics.arcade.collide(this.steen,this.turtle);
    this.physics.arcade.collide(this.steen1,this.turtle);

    this.physics.arcade.collide(this.finish,this.turtle,this.Finish,null,this);

    
    },

    carAway:function(){
        score +=1;
        scoreText.text = scoreString + score;

        
        
    },
    
   
	gameover:function(){        
		game.state.start('over');
	},

    render:function(){
            //game.debug.body(turtle);

    },


	Finish:function(){        
		game.state.start('win');
	}


};
