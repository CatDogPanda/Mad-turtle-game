var winState = {
	preload:function(){
		game.load.image('begin', 'assets/win.png');
	},

	create:function(){
		game.physics.startSystem(Phaser.Physics.ARCADE);
		game.add.image(0,0,'begin');


		var wkey = game.input.keyboard.addKey(Phaser.Keyboard.UP);
		wkey.onDown.addOnce(this.restart,this);

	},

	restart:function(){
		game.state.start('menu');

	}


}
