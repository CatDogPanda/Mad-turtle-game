

var menuState = {
	preload: function(){
		game.load.image('begin', 'assets/beginscherm.png');
		
	},

	create:function(){
		game.physics.startSystem(Phaser.Physics.ARCADE);
		menu = game.add.tileSprite(0,0,1000,560,'begin');
		
		

		var wkey = game.input.keyboard.addKey(Phaser.Keyboard.UP);

		wkey.onDown.addOnce(this.start,this);


	},

	start:function(){
		game.state.start('play');
	}
}
